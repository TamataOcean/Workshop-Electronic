var class_external_sensor_3_01_adafruit___a_d_s1115_01_4 =
[
    [ "ExternalSensor", "class_external_sensor_3_01_adafruit___a_d_s1115_01_4.html#aff5ed681a7c261462092516a5cc571e1", null ],
    [ "begin", "class_external_sensor_3_01_adafruit___a_d_s1115_01_4.html#a208a33108a08459d385b38cb2962376b", null ],
    [ "read", "class_external_sensor_3_01_adafruit___a_d_s1115_01_4.html#aa9ce4b3899967e9decdba76decf292af", null ],
    [ "sensor", "class_external_sensor_3_01_adafruit___a_d_s1115_01_4.html#a0e1585ff946f9ce0e259d515baa4ad54", null ]
];