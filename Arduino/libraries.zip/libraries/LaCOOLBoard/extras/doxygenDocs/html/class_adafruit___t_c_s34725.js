var class_adafruit___t_c_s34725 =
[
    [ "Adafruit_TCS34725", "class_adafruit___t_c_s34725.html#a2dd194daed0f6813b4e38f453e565572", null ],
    [ "begin", "class_adafruit___t_c_s34725.html#a568d79b6382ac27010a8afc26cbdae79", null ],
    [ "calculateColorTemperature", "class_adafruit___t_c_s34725.html#a9c6c7ab8a84a47a65ff04a125bcfee92", null ],
    [ "calculateLux", "class_adafruit___t_c_s34725.html#a10b9be546ee3bdf04e0380161aad589b", null ],
    [ "clearInterrupt", "class_adafruit___t_c_s34725.html#a731a3542039027f75170b667aaf8e3a0", null ],
    [ "disable", "class_adafruit___t_c_s34725.html#a79ac9b01a540f132d4bbf2edd2d6e8a2", null ],
    [ "enable", "class_adafruit___t_c_s34725.html#ad9a0e1f4f77d32dc0a6d604f7d1d5586", null ],
    [ "getRawData", "class_adafruit___t_c_s34725.html#abd9946a9baab1e0c76248cfe1864ea27", null ],
    [ "read16", "class_adafruit___t_c_s34725.html#a6b9b65ff0f1e57797a1c05a43fd25385", null ],
    [ "read8", "class_adafruit___t_c_s34725.html#a3ffafbdd475d6baf9abda8dd067b5319", null ],
    [ "setGain", "class_adafruit___t_c_s34725.html#a6be06315a9d33f76e44550f574f023a5", null ],
    [ "setIntegrationTime", "class_adafruit___t_c_s34725.html#a3c89fe5d4eea1f24f31d1afa9de8f0f3", null ],
    [ "setInterrupt", "class_adafruit___t_c_s34725.html#ae477b116ac93cf075be20637207aee57", null ],
    [ "setIntLimits", "class_adafruit___t_c_s34725.html#ac17b2447df066e30d1e64fe764f88770", null ],
    [ "write8", "class_adafruit___t_c_s34725.html#aa526557ad0d76b3b6e31e6197de583e6", null ],
    [ "_tcs34725Gain", "class_adafruit___t_c_s34725.html#ae614cd13b99a10b8e05ec78cab05c700", null ],
    [ "_tcs34725Initialised", "class_adafruit___t_c_s34725.html#ae9368bc77b501044f034d5d9ad3266ba", null ],
    [ "_tcs34725IntegrationTime", "class_adafruit___t_c_s34725.html#afbfddd381324226265955f436c82efd3", null ]
];