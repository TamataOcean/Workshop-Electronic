var class_external_sensor_3_01_dallas_temperature_01_4 =
[
    [ "ExternalSensor", "class_external_sensor_3_01_dallas_temperature_01_4.html#a5de0c37120d2d927bd0f37ff4a215baf", null ],
    [ "begin", "class_external_sensor_3_01_dallas_temperature_01_4.html#ac5275129b05e2ff8df45d5b222a661d9", null ],
    [ "read", "class_external_sensor_3_01_dallas_temperature_01_4.html#a1e725d9338314515d4e5dc456ed6a6c8", null ],
    [ "dallasAddress", "class_external_sensor_3_01_dallas_temperature_01_4.html#a7d9e9d2893e453638fcf440e5d8d9082", null ],
    [ "sensor", "class_external_sensor_3_01_dallas_temperature_01_4.html#adb6ba4fcdedef95ad8f6b0c9b6c0f9d1", null ]
];