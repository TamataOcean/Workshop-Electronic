var class_adafruit___a_d_s1015 =
[
    [ "Adafruit_ADS1015", "class_adafruit___a_d_s1015.html#a12dfb7b48af1a8e411c59f775c6457ab", null ],
    [ "begin", "class_adafruit___a_d_s1015.html#a6eba7c3cd854927f60883bb371e5faa6", null ],
    [ "getGain", "class_adafruit___a_d_s1015.html#a6232d089aaa82226bc34623fdf92237c", null ],
    [ "getLastConversionResults", "class_adafruit___a_d_s1015.html#ad8f36d80847020778425107f6451a8c2", null ],
    [ "readADC_Differential_0_1", "class_adafruit___a_d_s1015.html#a56582333958e66efaccd3d4a8a47e3ff", null ],
    [ "readADC_Differential_2_3", "class_adafruit___a_d_s1015.html#a38311881bcab46f7496c4bb6e4cad576", null ],
    [ "readADC_SingleEnded", "class_adafruit___a_d_s1015.html#a40f38b9e1f3ec397c0670dd632510235", null ],
    [ "setGain", "class_adafruit___a_d_s1015.html#a399441eace686975ff22937cbe45cc50", null ],
    [ "startComparator_SingleEnded", "class_adafruit___a_d_s1015.html#aecd30775d943ea9d9cff0e3485926596", null ],
    [ "m_bitShift", "class_adafruit___a_d_s1015.html#ab238ce17112a78db2be4ea14d57fb114", null ],
    [ "m_conversionDelay", "class_adafruit___a_d_s1015.html#aa3a29a64a6705fce1fee21d73c642a0e", null ],
    [ "m_gain", "class_adafruit___a_d_s1015.html#a8db90fe03d55a18246984ba2ba5e7f32", null ],
    [ "m_i2cAddress", "class_adafruit___a_d_s1015.html#a2186993621a7973256d47f086c74035d", null ]
];