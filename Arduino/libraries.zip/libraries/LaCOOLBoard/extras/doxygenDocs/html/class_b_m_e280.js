var class_b_m_e280 =
[
    [ "BME280", "class_b_m_e280.html#a9b9354e010528a0c3d452aa2459b808c", null ],
    [ "begin", "class_b_m_e280.html#a994c102f010547f9c740a338ef9905c7", null ],
    [ "readFloatAltitudeFeet", "class_b_m_e280.html#a6525c8a26f887b52596c86bed99343cb", null ],
    [ "readFloatAltitudeMeters", "class_b_m_e280.html#af67b56ba50760ee1d116acc6c5010221", null ],
    [ "readFloatHumidity", "class_b_m_e280.html#a42ea7232039eebf5aadb391ef6132c35", null ],
    [ "readFloatPressure", "class_b_m_e280.html#ada6e799917afb4f228e6253bc56ffe75", null ],
    [ "readRegister", "class_b_m_e280.html#a1bbd14c8591966df531e40085342ff71", null ],
    [ "readRegisterInt16", "class_b_m_e280.html#ac43c30f9b321d301694094d6b4bebe7e", null ],
    [ "readRegisterRegion", "class_b_m_e280.html#aecca87c2c40a7f2bcabcea921bdc6124", null ],
    [ "readTempC", "class_b_m_e280.html#afffdd1d7ded9e1f92200e70669019d97", null ],
    [ "readTempF", "class_b_m_e280.html#a9648b496f6b4700550782a715a98b3c7", null ],
    [ "reset", "class_b_m_e280.html#aeec5deb6daace6ae390108b4210e9df7", null ],
    [ "writeRegister", "class_b_m_e280.html#afcff21c342725246bf415d7f0e4d04f0", null ],
    [ "calibration", "class_b_m_e280.html#aa7a28484b6f5eb6f43261ea25016fbf8", null ],
    [ "settings", "class_b_m_e280.html#af06253eb2f8ad4b5fabb858bc4a973bf", null ],
    [ "t_fine", "class_b_m_e280.html#ad20f44914b78395f4d4bc64f4a68b369", null ]
];