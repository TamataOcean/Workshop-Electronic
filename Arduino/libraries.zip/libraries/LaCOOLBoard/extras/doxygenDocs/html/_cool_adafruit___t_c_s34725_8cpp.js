var _cool_adafruit___t_c_s34725_8cpp =
[
    [ "powf", "_cool_adafruit___t_c_s34725_8cpp.html#af1ff3aa3979ec4a3374156924ca49892", null ]
];