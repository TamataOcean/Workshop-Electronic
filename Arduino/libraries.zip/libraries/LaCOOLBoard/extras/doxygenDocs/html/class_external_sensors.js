var class_external_sensors =
[
    [ "sensor", "struct_external_sensors_1_1sensor.html", "struct_external_sensors_1_1sensor" ],
    [ "begin", "class_external_sensors.html#a58ede0d786a86417254708870f04a21e", null ],
    [ "config", "class_external_sensors.html#a862a4bd11346b37270d0244c2adabe5a", null ],
    [ "config", "class_external_sensors.html#ac829858f587e15a3fcb00567248f0edd", null ],
    [ "printConf", "class_external_sensors.html#a78c2bf55084435dd51d3c559b2d3c6f3", null ],
    [ "read", "class_external_sensors.html#a53177b81eca3be89508b5511ddcd00fc", null ],
    [ "sensors", "class_external_sensors.html#a284233f884fcf00154a44740cf1d9e1e", null ],
    [ "sensorsNumber", "class_external_sensors.html#a58e4fbf9adeae787d92be5fa33043b5d", null ]
];