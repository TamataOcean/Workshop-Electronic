var class_cool_wifi =
[
    [ "addWifi", "class_cool_wifi.html#a914d7a1df14dd6b75345fb614c34e9d6", null ],
    [ "begin", "class_cool_wifi.html#a46942fed90e475112cc10b78a32e7aaa", null ],
    [ "config", "class_cool_wifi.html#a4eb2f6b9b09dd588964b88b6c70122c0", null ],
    [ "config", "class_cool_wifi.html#a2a9a546f76816c8c5c8e2d46a6c4f07d", null ],
    [ "connect", "class_cool_wifi.html#ad060353050f40d032a2dbf9e54a768bf", null ],
    [ "connectAP", "class_cool_wifi.html#a7c857f27161782f5ef1d62d552aff971", null ],
    [ "connectWifiMulti", "class_cool_wifi.html#a419de92d738f14b7444cf822b3ab0070", null ],
    [ "printConf", "class_cool_wifi.html#a9e6105c6d13d35ec510f6633da9e0223", null ],
    [ "state", "class_cool_wifi.html#a1c7b4d82a4098d346e7593dce92039fa", null ],
    [ "nomad", "class_cool_wifi.html#ab7d9643c4af7bac3be331ef008b2ea27", null ],
    [ "pass", "class_cool_wifi.html#a0c3332a149245aaad060b32593a54c9b", null ],
    [ "ssid", "class_cool_wifi.html#a893b21d0fed821438733bba2e73fb4c2", null ],
    [ "timeOut", "class_cool_wifi.html#a952111605f25156588b5632caaba1c6f", null ],
    [ "wifiCount", "class_cool_wifi.html#ab133bd92fcb895b884deecd6678592e4", null ],
    [ "wifiMulti", "class_cool_wifi.html#a7862a8c0d7239877e2956c14a368aab8", null ]
];