var _cool_time_8h =
[
    [ "CoolTime", "class_cool_time.html", "class_cool_time" ],
    [ "NTP_PACKET_SIZE", "_cool_time_8h.html#a56a6ea64006651b4f42adf713e244f06", null ]
];