var class_external_sensor =
[
    [ "ExternalSensor", "class_external_sensor.html#a8b991447fba33253103d06198b838751", null ],
    [ "begin", "class_external_sensor.html#ab6fe1379d55b656a048e0fba1e0a32e6", null ],
    [ "read", "class_external_sensor.html#a5fb3afc7d244fb86dac68ab5481bc407", null ],
    [ "sensor", "class_external_sensor.html#a6e1f518119abe08c14b498ce24a7e1b3", null ]
];