var class_cool_time =
[
    [ "begin", "class_cool_time.html#ab1976cf718b950bc31e003c3323b8adb", null ],
    [ "config", "class_cool_time.html#a87c28260c1bc77091162cbcf1ee2e129", null ],
    [ "config", "class_cool_time.html#a014656d0d3f74d6391364b92b13e0780", null ],
    [ "formatDigits", "class_cool_time.html#acd537cd4210d7bde4e1f5c47d2ac0456", null ],
    [ "getESDate", "class_cool_time.html#ac4f32ee513c1328d984306645e8785a4", null ],
    [ "getLastSyncTime", "class_cool_time.html#a5d17f707a9d337720493b2bce9d41c21", null ],
    [ "getNtpTime", "class_cool_time.html#a41fbbbfd651c2079f54d4b2911e4c705", null ],
    [ "getTimeDate", "class_cool_time.html#a7a7501c5ca77dd1248bea704c44f986c", null ],
    [ "isTimeSync", "class_cool_time.html#a5ae038a4498602b189f76a10bf02adf8", null ],
    [ "printConf", "class_cool_time.html#af355e7f9b3898211cd2ff25eab5933b1", null ],
    [ "saveTimeSync", "class_cool_time.html#ae9658c9b377510d469e3b88edf33ee85", null ],
    [ "sendNTPpacket", "class_cool_time.html#a236a38d120dc53bc67456d763838c5a1", null ],
    [ "setDateTime", "class_cool_time.html#ab81ea7fdaace111aa01cc1ec84c6d297", null ],
    [ "update", "class_cool_time.html#aae601f795452cfa48d9fb337aed483a8", null ],
    [ "localPort", "class_cool_time.html#a2f777da44d7ba678be8185299e9b49d1", null ],
    [ "packetBuffer", "class_cool_time.html#a27e6abc82a5c2f72161956967005bec7", null ],
    [ "rtc", "class_cool_time.html#abd38f2384ff90692b1568d9db869412e", null ],
    [ "timeServer", "class_cool_time.html#ad2b9858f399108cb440dd1e908916f04", null ],
    [ "timeSync", "class_cool_time.html#a9d032e76c3470a15b3bbbc52af6463f7", null ],
    [ "tmSet", "class_cool_time.html#ad33c2713c903ff064ad09c46406ae088", null ],
    [ "Udp", "class_cool_time.html#a4e23216a8121ca79d0fb019f30884b92", null ]
];