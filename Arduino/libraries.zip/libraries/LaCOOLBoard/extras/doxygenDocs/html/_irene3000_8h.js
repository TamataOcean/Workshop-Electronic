var _irene3000_8h =
[
    [ "Irene3000", "class_irene3000.html", "class_irene3000" ],
    [ "parameters_T", "struct_irene3000_1_1parameters___t.html", "struct_irene3000_1_1parameters___t" ],
    [ "state", "struct_irene3000_1_1state.html", "struct_irene3000_1_1state" ],
    [ "ADC_MAXIMUM_VALUE", "_irene3000_8h.html#ae04444a85a37b5dce09107f2ce2b2c80", null ],
    [ "button", "_irene3000_8h.html#a37976ee6fe1fb8546bfd6153b83ffa6c", null ],
    [ "freeAdc", "_irene3000_8h.html#a55497513af255250e464ed76543d46d7", null ],
    [ "ph", "_irene3000_8h.html#af771ceafe0e6524dd8497d4305dfe778", null ],
    [ "REFERENCE_VOLTAGE_GAIN_4", "_irene3000_8h.html#a51af1d267f8d2e05eff1e4f5c88d02e5", null ],
    [ "temp", "_irene3000_8h.html#a5905d48604152cf57aa6bfa087b49173", null ],
    [ "V_GAIN_2", "_irene3000_8h.html#a905a3e9dbe2e4aef45dda002f2f6993d", null ],
    [ "V_GAIN_4", "_irene3000_8h.html#a9a0ac774ada946f154982546852e8fb6", null ],
    [ "V_GAIN_8", "_irene3000_8h.html#ab7ab16df599d3f0ce29e12791a504891", null ],
    [ "Write_Check", "_irene3000_8h.html#a9fa3b8fd890fde289060ee254cd273d5", null ]
];