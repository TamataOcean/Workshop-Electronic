var _cool_adafruit___a_d_s1015_8cpp =
[
    [ "i2cread", "_cool_adafruit___a_d_s1015_8cpp.html#af89e2442d757f6ec8100c473022f6701", null ],
    [ "i2cwrite", "_cool_adafruit___a_d_s1015_8cpp.html#a6db5edba66e20bba6d5b421c2789af54", null ],
    [ "readRegister", "_cool_adafruit___a_d_s1015_8cpp.html#a319539381b7551b2f83a92b0b596e97d", null ],
    [ "writeRegister", "_cool_adafruit___a_d_s1015_8cpp.html#a00ef55774dfb93dd0a7bf561d8451b71", null ]
];