var class_cool_board_sensors =
[
    [ "airActive", "struct_cool_board_sensors_1_1air_active.html", "struct_cool_board_sensors_1_1air_active" ],
    [ "lightActive", "struct_cool_board_sensors_1_1light_active.html", "struct_cool_board_sensors_1_1light_active" ],
    [ "CoolBoardSensors", "class_cool_board_sensors.html#a91ff2a02f5486f90cf2413a1cf8a9ed4", null ],
    [ "allActive", "class_cool_board_sensors.html#aa432c5aac88f89c31a10766390f23e0b", null ],
    [ "begin", "class_cool_board_sensors.html#a97095823ef7c8f5290812f1405b966b3", null ],
    [ "config", "class_cool_board_sensors.html#a9a218895c5423375c33c08f2c56fb23a", null ],
    [ "end", "class_cool_board_sensors.html#a4902b69f6e628bd6557193758fdd2bae", null ],
    [ "printConf", "class_cool_board_sensors.html#af6fd79505815b204c178617ecf54c873", null ],
    [ "read", "class_cool_board_sensors.html#a91badb2539d91fda8679f2a597874c48", null ],
    [ "readMoisture", "class_cool_board_sensors.html#a8761bff50373c485f4465c8db47d0633", null ],
    [ "readVBat", "class_cool_board_sensors.html#a6944b6ea7bce8e2fce1b434acfd9d5f3", null ],
    [ "setEnvSensorSettings", "class_cool_board_sensors.html#a406307ffd70272282d91479c7ed8d66f", null ],
    [ "airDataActive", "class_cool_board_sensors.html#abff8dfeccb2f7689847bb64d5f1cd31e", null ],
    [ "AnMplex", "class_cool_board_sensors.html#a12ef28b1046219e0aee10bf64e28c4a5", null ],
    [ "EnMoisture", "class_cool_board_sensors.html#a6177d02e14a057a2f171a2e930b5038d", null ],
    [ "envSensor", "class_cool_board_sensors.html#a868e38985e9a2412829fa2790ca13e2e", null ],
    [ "lightDataActive", "class_cool_board_sensors.html#ac4deb1cf41bac8b91c780c92fab00ba4", null ],
    [ "lightSensor", "class_cool_board_sensors.html#ac711c27d0927eb5e73be77f092c48be0", null ],
    [ "soilMoistureActive", "class_cool_board_sensors.html#ae7971bf527781ac4994309591b78ab89", null ],
    [ "vbatActive", "class_cool_board_sensors.html#ab0b4bbae83796b52b90f91008d383583", null ]
];