var class_external_sensor_3_01_adafruit___a_d_s1015_01_4 =
[
    [ "ExternalSensor", "class_external_sensor_3_01_adafruit___a_d_s1015_01_4.html#a5785138360de1f92f248c77f1d8e4536", null ],
    [ "begin", "class_external_sensor_3_01_adafruit___a_d_s1015_01_4.html#adb62166ec1ff937acd82650ff44320d6", null ],
    [ "read", "class_external_sensor_3_01_adafruit___a_d_s1015_01_4.html#a6c41a80525743b24bcc64744bbfb91bb", null ],
    [ "sensor", "class_external_sensor_3_01_adafruit___a_d_s1015_01_4.html#a9492450437bd0fe277dcb851177aa8fe", null ]
];