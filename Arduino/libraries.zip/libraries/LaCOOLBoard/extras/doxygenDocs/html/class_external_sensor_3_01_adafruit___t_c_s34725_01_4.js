var class_external_sensor_3_01_adafruit___t_c_s34725_01_4 =
[
    [ "ExternalSensor", "class_external_sensor_3_01_adafruit___t_c_s34725_01_4.html#a3b1855d165d295332b53e074344e3281", null ],
    [ "begin", "class_external_sensor_3_01_adafruit___t_c_s34725_01_4.html#ad9c1d1ac1f34ce1c153a0563d9cc55df", null ],
    [ "read", "class_external_sensor_3_01_adafruit___t_c_s34725_01_4.html#a129ee155fe53aa069cb972bcf52e25f7", null ],
    [ "sensor", "class_external_sensor_3_01_adafruit___t_c_s34725_01_4.html#aa1c5cc9eec53c08392f63346c9a4cd47", null ]
];