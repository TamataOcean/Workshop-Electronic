var _cool_board_8cpp =
[
    [ "DEBUG", "_cool_board_8cpp.html#ad72dbcf6d0153db1b8d8a58001feed83", null ]
];