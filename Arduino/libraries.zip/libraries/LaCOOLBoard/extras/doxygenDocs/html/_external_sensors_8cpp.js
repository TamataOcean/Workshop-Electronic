var _external_sensors_8cpp =
[
    [ "DEBUG", "_external_sensors_8cpp.html#ad72dbcf6d0153db1b8d8a58001feed83", null ],
    [ "oneWire", "_external_sensors_8cpp.html#af39fa3dad1ba161b384c0b26b8145e65", null ]
];