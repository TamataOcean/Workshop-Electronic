var class_external_sensor_3_01_n_d_i_r___i2_c_01_4 =
[
    [ "ExternalSensor", "class_external_sensor_3_01_n_d_i_r___i2_c_01_4.html#aa06970ea689679c0e1deb5360e05a0a4", null ],
    [ "begin", "class_external_sensor_3_01_n_d_i_r___i2_c_01_4.html#ac6f3614d94968ef0cc11b2b4d69cef03", null ],
    [ "read", "class_external_sensor_3_01_n_d_i_r___i2_c_01_4.html#a239d18652e9fb4673842ae9726edf44f", null ],
    [ "sensor", "class_external_sensor_3_01_n_d_i_r___i2_c_01_4.html#ae541c9cece7c38674b70114cdb74a7dc", null ]
];