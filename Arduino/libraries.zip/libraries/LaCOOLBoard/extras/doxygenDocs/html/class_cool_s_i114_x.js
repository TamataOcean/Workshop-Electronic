var class_cool_s_i114_x =
[
    [ "Begin", "class_cool_s_i114_x.html#a206b36aca7049f63be1d11088c30a09f", null ],
    [ "DeInit", "class_cool_s_i114_x.html#a6840abd53a2e3d71a6bb918077c6d6e6", null ],
    [ "ReadByte", "class_cool_s_i114_x.html#acc20f8037e156ec4aadcbe90780b1e8b", null ],
    [ "ReadHalfWord", "class_cool_s_i114_x.html#a1d25c9e137874af529804c2ec796a6b9", null ],
    [ "ReadIR", "class_cool_s_i114_x.html#abc536ee7ae8e3ba9d1069acc3889a2cf", null ],
    [ "ReadParamData", "class_cool_s_i114_x.html#a33cf431103c722442f6a0cc93848d640", null ],
    [ "ReadProximity", "class_cool_s_i114_x.html#a194fede1105508c7803dbb567cbdcc67", null ],
    [ "ReadResponseReg", "class_cool_s_i114_x.html#a869d3825147831d707f7ef324a665646", null ],
    [ "ReadUV", "class_cool_s_i114_x.html#a14ced664d74e93438440b0274109c111", null ],
    [ "ReadVisible", "class_cool_s_i114_x.html#a42e0e574256341443c647a4c0eda87d5", null ],
    [ "Reset", "class_cool_s_i114_x.html#a9d9f9c9129c0c29ed497f8563f3dd823", null ],
    [ "WriteByte", "class_cool_s_i114_x.html#ac5c8dc5ade604da7a1c8cd1586feefc2", null ],
    [ "WriteParamData", "class_cool_s_i114_x.html#abf45eb10a6de1be16e68a51624fa2608", null ]
];