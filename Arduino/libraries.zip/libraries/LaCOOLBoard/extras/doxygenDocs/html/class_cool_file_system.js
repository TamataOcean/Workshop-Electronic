var class_cool_file_system =
[
    [ "begin", "class_cool_file_system.html#a6ba6f666ed4c530174f8569d2c636748", null ],
    [ "fileUpdate", "class_cool_file_system.html#a13f2958f5b87757c31fc53797a30d23a", null ],
    [ "getsavedData", "class_cool_file_system.html#a70701d05e811604af1b531f4f6dc69ed", null ],
    [ "getSensorSavedData", "class_cool_file_system.html#a3223ffff4266a6300988fab956d6b4b2", null ],
    [ "incrementsavedData", "class_cool_file_system.html#aae045125288f255f3e258073dcada2a6", null ],
    [ "isDataSaved", "class_cool_file_system.html#ac86a40e7c3a1842f7342f698d34324f9", null ],
    [ "saveSensorData", "class_cool_file_system.html#afa3a4feae94871d4d3b6bebb701c2e67", null ],
    [ "saveSensorDataCSV", "class_cool_file_system.html#ab78704d5d21ce10fc6f1138ab5ab46c8", null ],
    [ "updateConfigFiles", "class_cool_file_system.html#adfa8e2e80641ae6f0cceabd348a9b841", null ],
    [ "linesToSkip", "class_cool_file_system.html#a84fdb6057e534b395512463daa28ea3c", null ],
    [ "savedData", "class_cool_file_system.html#ad9f5b739a32100f5f21270c3d9ee2b1d", null ]
];