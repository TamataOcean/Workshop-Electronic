var class_adafruit___a_d_s1115 =
[
    [ "Adafruit_ADS1115", "class_adafruit___a_d_s1115.html#a7058cf2c75b673fb0b0a8936c3edd1fd", null ]
];