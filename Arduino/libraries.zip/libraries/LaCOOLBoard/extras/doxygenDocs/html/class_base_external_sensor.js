var class_base_external_sensor =
[
    [ "BaseExternalSensor", "class_base_external_sensor.html#a978d96a6563b646efb358c2790a9fc6f", null ],
    [ "begin", "class_base_external_sensor.html#a87d132803d4f4fdd4e66332809f0c9a0", null ],
    [ "read", "class_base_external_sensor.html#a1564f16deacf57b51b9948ac29db4291", null ],
    [ "read", "class_base_external_sensor.html#a1867ba10561be26f2f5ec29421e6fb21", null ]
];