var _external_sensor_8h =
[
    [ "BaseExternalSensor", "class_base_external_sensor.html", "class_base_external_sensor" ],
    [ "ExternalSensor", "class_external_sensor.html", "class_external_sensor" ],
    [ "ExternalSensor< NDIR_I2C >", "class_external_sensor_3_01_n_d_i_r___i2_c_01_4.html", "class_external_sensor_3_01_n_d_i_r___i2_c_01_4" ],
    [ "ExternalSensor< DallasTemperature >", "class_external_sensor_3_01_dallas_temperature_01_4.html", "class_external_sensor_3_01_dallas_temperature_01_4" ],
    [ "ExternalSensor< Adafruit_TCS34725 >", "class_external_sensor_3_01_adafruit___t_c_s34725_01_4.html", "class_external_sensor_3_01_adafruit___t_c_s34725_01_4" ],
    [ "ExternalSensor< Adafruit_ADS1015 >", "class_external_sensor_3_01_adafruit___a_d_s1015_01_4.html", "class_external_sensor_3_01_adafruit___a_d_s1015_01_4" ],
    [ "ExternalSensor< Adafruit_ADS1115 >", "class_external_sensor_3_01_adafruit___a_d_s1115_01_4.html", "class_external_sensor_3_01_adafruit___a_d_s1115_01_4" ],
    [ "DEBUGExternal", "_external_sensor_8h.html#a0b45b8250f7c347a94f27241745f0f04", null ]
];